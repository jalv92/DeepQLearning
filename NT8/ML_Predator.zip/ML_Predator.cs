#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private HFT_TheStrat_ML[] cacheHFT_TheStrat_ML;

		
		public HFT_TheStrat_ML HFT_TheStrat_ML()
		{
			return HFT_TheStrat_ML(Input);
		}


		
		public HFT_TheStrat_ML HFT_TheStrat_ML(ISeries<double> input)
		{
			if (cacheHFT_TheStrat_ML != null)
				for (int idx = 0; idx < cacheHFT_TheStrat_ML.Length; idx++)
					if ( cacheHFT_TheStrat_ML[idx].EqualsInput(input))
						return cacheHFT_TheStrat_ML[idx];
			return CacheIndicator<HFT_TheStrat_ML>(new HFT_TheStrat_ML(), input, ref cacheHFT_TheStrat_ML);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.HFT_TheStrat_ML HFT_TheStrat_ML()
		{
			return indicator.HFT_TheStrat_ML(Input);
		}


		
		public Indicators.HFT_TheStrat_ML HFT_TheStrat_ML(ISeries<double> input )
		{
			return indicator.HFT_TheStrat_ML(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.HFT_TheStrat_ML HFT_TheStrat_ML()
		{
			return indicator.HFT_TheStrat_ML(Input);
		}


		
		public Indicators.HFT_TheStrat_ML HFT_TheStrat_ML(ISeries<double> input )
		{
			return indicator.HFT_TheStrat_ML(input);
		}

	}
}

#endregion
