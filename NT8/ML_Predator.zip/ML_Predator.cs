#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private ML_Predator[] cacheML_Predator;

		
		public ML_Predator ML_Predator()
		{
			return ML_Predator(Input);
		}


		
		public ML_Predator ML_Predator(ISeries<double> input)
		{
			if (cacheML_Predator != null)
				for (int idx = 0; idx < cacheML_Predator.Length; idx++)
					if ( cacheML_Predator[idx].EqualsInput(input))
						return cacheML_Predator[idx];
			return CacheIndicator<ML_Predator>(new ML_Predator(), input, ref cacheML_Predator);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.ML_Predator ML_Predator()
		{
			return indicator.ML_Predator(Input);
		}


		
		public Indicators.ML_Predator ML_Predator(ISeries<double> input )
		{
			return indicator.ML_Predator(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.ML_Predator ML_Predator()
		{
			return indicator.ML_Predator(Input);
		}


		
		public Indicators.ML_Predator ML_Predator(ISeries<double> input )
		{
			return indicator.ML_Predator(input);
		}

	}
}

#endregion
